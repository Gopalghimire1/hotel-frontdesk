export class Setting {
 public static url="https://hotel.gharsaaman.com/";
}
