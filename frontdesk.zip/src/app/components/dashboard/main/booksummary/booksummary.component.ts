import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booksummary',
  templateUrl: './booksummary.component.html',
  styleUrls: ['./booksummary.component.scss']
})
export class BooksummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
